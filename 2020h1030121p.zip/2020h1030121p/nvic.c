#include "gpio.h"
#include "nvic.h"
#include "string.h"
#include "stm32f4xx.h"

void NVIC_GPIO_INIT (void){   
	EXTI->IMR=0x00000001;
	EXTI->RTSR=0x00000001;   
	NVIC_SetPriorityGrouping(5); 
	
	NVIC_SetPriority(EXTI0_IRQn,2);
	NVIC_SetPriority(EXTI1_IRQn,1);
	NVIC_SetPriority(EXTI2_IRQn,0);
}

void EXTI_INIT(char pin[]){
	//depending upon value read is PA0/PB0/PC0
		if(!strcmp(pin, "PA0") || !strcmp(pin, "PB0") || !strcmp(pin, "PC0")){
				NVIC_EnableIRQ(EXTI0_IRQn);
		}else if(!strcmp(pin, "PA1") || !strcmp(pin, "PB1") || !strcmp(pin, "PC1")){
				NVIC_EnableIRQ(EXTI1_IRQn);
		}else if(!strcmp(pin, "PA2") || !strcmp(pin, "PB2") || !strcmp(pin, "PC2")){
				NVIC_EnableIRQ(EXTI2_IRQn);
		}
}

void EXTI0_IRQHandler(void){
	GPIO_LEDs0_ON();
}

void EXTI1_IRQHandler(void){
	GPIO_LEDs1_ON();
}

void EXTI2_IRQHandler(void){
	GPIO_LEDs2_ON();
}