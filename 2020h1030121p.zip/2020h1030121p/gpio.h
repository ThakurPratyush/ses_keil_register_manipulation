void GPIO_USER_INIT (void);
void GPIO_BUTTONs_INIT(void);
void GPIO_LEDs0_ON(void);
void GPIO_LEDs1_ON(void);
void GPIO_LEDs2_ON(void);
void PORT_INIT(char pin[], char configuration[]);