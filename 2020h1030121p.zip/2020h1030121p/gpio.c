#include "gpio.h"
#include "nvic.h"
#include "string.h"
#include "stm32f4xx.h"


void GPIO_USER_INIT (void){ 
	RCC->AHB1ENR=RCC->AHB1ENR|0x00000001;//Enabling GPIOA  
	GPIOA->PUPDR =  GPIOA->PUPDR|0;
	GPIOA->MODER=GPIOA->MODER|0;
}

void PORT_INIT(char pin[], char configuration[]){
		
	//the value of the port is input in the variable port 
	char port = pin[1];
	
	// get the vaue of o in the pin 0 
	int pinNo =0;
	// comparing the sting length of the variable pin
	if(strlen(pin) == 3){
      pinNo = pin[2] - '0';  
  }else{
      pinNo = ((pin[2] - '0') * 10) + pin[3] - '0';
  } 
	
	if(!strcmp(configuration, "INPUT")){
		// checking the configration is INPUT 
		// and updating the registers
				unsigned int three = 0x00000003;
				unsigned int allOnes = 0xffffffff;
		
				three = (three << (pinNo*2));
				three ^= allOnes;
		//UPDATING  the GIPO REGISTER VALUE depending upon value in the port variable
        switch(port) {
            case 'A' :
							GPIOA->MODER &= three;
                break;
            case 'B' :
                GPIOB->MODER &= three;
                break;
            case 'C' :
                GPIOC->MODER &= three;
                break;
        }
	
	// if  the alue of configration is output
    }else if(!strcmp(configuration, "OUTPUT")){
			
					unsigned int one = 0x00000001; // values of 1 in the register one
					unsigned int all = 0xffffffff; //all ones in the variable all
		
					one = (one << (pinNo*2+1));
					one ^= all;
			
			switch(port) {			// using port variable to update
            case 'A' :
                GPIOA->MODER &= one;
								GPIOA->MODER |= (1U << (pinNo*2));
                break;
            case 'B' :
                GPIOB->MODER &= one;
								GPIOB->MODER |= (1U << (pinNo*2));
                break;
            case 'C' :
                GPIOC->MODER &= one;
								GPIOC->MODER |= (1U << (pinNo*2));
                break;
        }	
			
    }
	
}



void GPIO_BUTTONs_INIT(void){ 
	RCC->AHB1ENR=RCC->AHB1ENR|0x00000002;//Enabling GPIOB 
	RCC->AHB1ENR=RCC->AHB1ENR|0x00000004;//Enabling GPIOC
	//values updated
	GPIOA->PUPDR = 0x0000000;
	GPIOA->OTYPER=0x0000;
	
	GPIOB->PUPDR = 0x0000000;
	GPIOB->OTYPER=0x0000;
	
	GPIOC->PUPDR = 0x0000000;
	GPIOC->OTYPER=0x0000;
}
void GPIO_LEDs0_ON(void){
	
	if((GPIOA->ODR & 0x0001) == 0x0001){
		GPIOA->ODR = 0x2000;
	}else if((GPIOB->ODR & 0x0001) == 0x0001){
		GPIOB->ODR = 0x2000;
	}else if((GPIOC->ODR & 0x0001) == 0x0001){
		GPIOC->ODR = 0x2000;
	}
}


void GPIO_LEDs1_ON(void){
	
	if((GPIOA->ODR & 0x0002) == 0x0002){
		GPIOA->ODR = 0x4000;
	}else if((GPIOB->ODR & 0x0002) == 0x0002){
		GPIOB->ODR = 0x4000;
	}else if((GPIOC->ODR & 0x0002) == 0x0002){
		GPIOC->ODR = 0x4000;
	}
}


void GPIO_LEDs2_ON(void){
	
	if((GPIOA->ODR & 0x0004) == 0x0004){
		GPIOA->ODR = 0x8000;
	}else if((GPIOB->ODR & 0x0004) == 0x0004){
		GPIOB->ODR = 0x8000;
	}else if((GPIOC->ODR & 0x0004) == 0x0004){
		GPIOC->ODR = 0x8000;
	}
}