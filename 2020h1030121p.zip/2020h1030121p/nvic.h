void NVIC_GPIO_INIT (void);
void EXTI0_IRQHandler(void);
void EXTI1_IRQHandler(void);
void EXTI2_IRQHandler(void);
void EXTI_INIT(char pin[]);