#include "nvic.h"
#include "gpio.h"
#include "stm32f4xx.h"
int main(void){
	
	GPIO_USER_INIT();//pa0 
	NVIC_GPIO_INIT();//ext nvic
	GPIO_BUTTONs_INIT(); 
		
	PORT_INIT("PA0", "INPUT");
	PORT_INIT("PB0", "INPUT");
	PORT_INIT("PC0", "INPUT");
	PORT_INIT("PA1", "INPUT");
	PORT_INIT("PB1", "INPUT");
	PORT_INIT("PC1", "INPUT");
	PORT_INIT("PA2", "INPUT");
	PORT_INIT("PB2", "INPUT");
	PORT_INIT("PC2", "INPUT");
	
	PORT_INIT("PA13", "OUTPUT");
	PORT_INIT("PB13", "OUTPUT");
	PORT_INIT("PC13", "OUTPUT");
	PORT_INIT("PA14", "OUTPUT");
	PORT_INIT("PB14", "OUTPUT");
	PORT_INIT("PC14", "OUTPUT");
	PORT_INIT("PA15", "OUTPUT");
	PORT_INIT("PB15", "OUTPUT");
	PORT_INIT("PC15", "OUTPUT");
	
	EXTI_INIT("PB0");
	EXTI_INIT("PC1");
	EXTI_INIT("PA2");
	// running the loop infinitely
	while (1);
}